var mes = 7;
if(mes==12 || mes==1 || mes==2){
  document.write("es invierno")
}else if(mes>=3 && mes<=5){
  document.write("es primavera")
}else if(mes>=6 && mes <=8){
  document.write("es verano")
}else if(mes>=9 && mes<=11){
  document.write("es otoño")
}
document.write("20052064 - Bryan Alexander Jauregui Argueta")